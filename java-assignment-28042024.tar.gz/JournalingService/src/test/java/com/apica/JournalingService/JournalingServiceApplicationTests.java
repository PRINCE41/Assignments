package com.apica.JournalingService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JournalingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
