package com.apica.UserMngService.dtos;

import lombok.Data;

@Data
public class LoginUserDto {
    private String uId;
    private String password;
}
