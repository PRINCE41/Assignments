package com.apica.UserMngService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserMngServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
